This directory contains:

- Ground truth directory quesst2014_dev containing ecf, tlist and rttm
  files for the development dataset (needed by the TWV scoring script):

      - quesst2014.ecf.xml
      - quesst2014_dev.rttm
      - quesst2014_dev.tlist.xml

- Ground truth directories quesst2014_dev_T1, quesst2014_dev_T2 and
  quesst2014_dev_T3, containing ecf, tlist and rttm files for the
  subsets of queries of types 1, 2 and 3, respectively. These directories
  allow us to measure system performance on a specific type of queries.

- The TWV/Cnxe scoring script for Mediaeval QUESST 2014:

      - score-TWV-Cnxe.sh

- Scoring tool for Mediaeval QUESST 2014:

      - MediaEvalQUESST2014.jar

- Example STD directory, including a complete fake system
  (created from a real system submitted to Mediaeval SWS 2013):

      - example_STD

- A second example STD directory, including an incomplete fake system:

      - example_STD_incomplete 

  If an incomplete system is submitted, participants must provide
  a default score, which will be used to compute both the Cnxe value
  and TWV metrics.

- Example ground truth directory (created from real ground truth files
  used in Mediaeval SWS 2013):

      - example_GroundTruth

- This README file


How to use the scoring script
=============================

1. Systems are expected to produce a complete set of detections
   (i.e. they produce a score for each trial) in a .stdlist.xml file
   with the format described in the NIST 2006 STD Evaluation Plan
   (see http://www.itl.nist.gov/iad/mig/tests/std/2006/).
   The fake system included in the example_STD directory can be used
   as template.

2. A directory must be created containing the .stdlist.xml file.

3. The directory where the scoring script is located must also contain
   the MediaEvalQUESST2014.jar tool.

4. The scoring command should be as follows:

   ./score-TWV-Cnxe.sh <STDLIST_dir> <Ground_Truth_dir> [<default_score>]

   For instance, to score the example system output stored in the
   example_STD directory:

   ./score-TWV-Cnxe.sh example_sws2013dev groundtruth_sws2013_dev 

   To score the example incomplete system output stored in the
   example_sws2013dev_incomplete directory (using a default -10 score):

   ./score-TWV-Cnxe.sh example_sws2013dev_incomplete groundtruth_sws2013_dev -10

   Same for an incomplete subset of the quesst 2014 development set:

   ./score-TWV-Cnxe.sh example_quesst14dev groundtruth_quesst14_dev -10

5. Once the scoring script finishes, results (score.out, DET.pdf and TWV.pdf)
   are stored in the same directory where the .stdlist.xml file was located.
